<footer class="app-footer">
    <div class="container" align="center">		
	<center>
				<tr>
					<td align="center"><a title="Facultad de ciencias y Tecnologia" href="http://fcyt.uader.edu.ar"><img src="../img/fcyt.jpg" width="150px" height="80px" alt="Facultad de ciencias y Tecnologia" /></a>
				
					<p>Facultad de Ciencia y Tecnologia - UADER<br>
					Km 5 1/2 Telefono: 0343-Nolose
					</p></td>
				</tr>
			
	</center>
				
</div>
</footer>
